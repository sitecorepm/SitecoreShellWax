Configuring the "Task Schedule Field Editor":
1. Change the field type of the "Schedule" field on the template "/sitecore/templates/System/Tasks/Schedule" from "text" to "IFrame"
2. In the field source enter: "/sitecore modules/shell/editors/TaskSchedule/TaskSchedule.aspx?field=Schedule"
3. On the /sitecore/templates/System/Tasks/Schedule/Data/Schedule item, select View-->Standard Fields
4. Goto the "Style" field in the "Appearance" section and add this value: "height:250px"